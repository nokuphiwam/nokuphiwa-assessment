public class EventService
{
    private readonly DbContext _context;

    public EventService(DbContext context)
    {
        _context = context;
    }

    public async Task<IEnumerable<Event>> GetEventsAsync()
    {
        return await _context.Events.ToListAsync();
    }

    public async Task<Event> GetEventAsync(int id)
    {
        return await _context.Events.FindAsync(id);
    }

    public async Task<Event> CreateEventAsync(Event @event)
    {
        _context.Events.Add(@event);
        await _context.SaveChangesAsync();
        return @event;
    }

    public async Task<Event> UpdateEventAsync(int id, Event @event)
    {
        var existingEvent = await _context.Events.FindAsync(id);
        if (existingEvent != null)
        {
            existingEvent.Name = @event.Name;
            existingEvent.Date = @event.Date;
            existingEvent.SeatsAvailable = @event.SeatsAvailable;
            await _context.SaveChangesAsync();
            return existingEvent;
        }
        return null;
    }

    public async Task DeleteEventAsync(int id)
    {
        var @event = await _context.Events.FindAsync(id);
        if (@event != null)
        {
            _context.Events.Remove(@event);
            await _context.SaveChangesAsync();
        }
    }
}