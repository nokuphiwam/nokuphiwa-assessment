[ApiController]
[Route("api/[controller]")]
public class EventsController : ControllerBase
{
    private readonly IEventService _eventService;

    public EventsController(IEventService eventService)
    {
        _eventService = eventService;
    }

    [HttpGet]
    public async Task<ActionResult<IEnumerable<Event>>> GetEvents()
    {
        return await _eventService.GetEventsAsync();
    }

    [HttpGet("{id}")]
    public async Task<ActionResult<Event>> GetEvent(int id)
    {
        return await _eventService.GetEventAsync(id);
    }

    [HttpPost]
    public async Task<ActionResult<Event>> CreateEvent(Event @event)
    {
        return await _eventService.CreateEventAsync(@event);
    }

    [HttpPut("{id}")]
    public async Task<ActionResult<Event>> UpdateEvent(int id, Event @event)
    {
        return await _eventService.UpdateEventAsync(id, @event);
    }

    [HttpDelete("{id}")]
    public async Task<ActionResult> DeleteEvent(int id)
    {
        await _eventService.DeleteEventAsync(id);
        return NoContent();
    }
}
